"""Dependency-free package checks; does not substitute for Spark integration tests."""
import ast
import re
from pathlib import Path
from urllib.parse import urlsplit

root = Path(__file__).resolve().parent
for path in root.rglob('*.py'):
    if '.venv' not in path.parts:
        ast.parse(path.read_text(), filename=str(path))
html = (root/'dist/index.html').read_text(encoding='utf-8')
ids = set(re.findall(r'id="([^"]+)"',html))
for href in re.findall(r'(?:href|src)="([^"]+)"',html):
    url = urlsplit(href)
    if url.scheme:
        continue
    if url.path:
        assert (root/'dist'/url.path).exists(), f'Missing asset: {href}'
    if url.fragment:
        assert url.fragment in ids, f'Missing anchor: {href}'
assert len(re.findall(r'id="([^"]+)"',html)) == len(ids), 'Duplicate IDs'
print('Python syntax and website local links passed.')
